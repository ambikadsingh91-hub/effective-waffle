import type { LotApi, LotListing, LotTransaction, LotUser } from '../types.js'
import { randomUUID } from 'node:crypto'

const users = new Map<string,{user:LotUser,password:string,balance:number}>()
users.set('demo', {user:{id:'u_demo',username:'DemoUser',email:'demo@lot.local'},password:'demo1234',balance:5000})
const listings:LotListing[] = [
 {id:'l1',name:'Golden Sword',description:'A rare golden sword.',imageUrl:'',category:'Weapons',priceLot:250,stock:12,sellerId:'u_seller',sellerUsername:'Player123',itemsSold:8,totalEarnedLot:2000,active:true},
 {id:'l2',name:'Neon Crown',description:'Limited neon collectible.',imageUrl:'',category:'Collectibles',priceLot:850,stock:3,sellerId:'u_seller2',sellerUsername:'Nova',itemsSold:4,totalEarnedLot:3400,active:true},
 {id:'l3',name:'Shadow Pack',description:'A sleek cosmetic accessory pack.',imageUrl:'',category:'Accessories',priceLot:120,stock:27,sellerId:'u_seller3',sellerUsername:'Rex',itemsSold:18,totalEarnedLot:2160,active:true},
 {id:'l4',name:'Arcade Pass',description:'Unlocks a collection of classic games.',imageUrl:'',category:'Games',priceLot:500,stock:7,sellerId:'u_seller4',sellerUsername:'PixelFox',itemsSold:13,totalEarnedLot:6500,active:true}
]
const transactions:LotTransaction[] = []
const tokens = new Map<string,string>()
export const mockLotApi: LotApi = {
 async loginUser(identifier,password){const rec=[...users.values()].find(x=>x.user.username===identifier||x.user.email===identifier);if(!rec||rec.password!==password)throw new Error('Invalid username/email or password');const token=randomUUID();tokens.set(token,rec.user.id);return {accessToken:token,user:rec.user}},
 async getCurrentUser(token){const id=tokens.get(token);const rec=[...users.values()].find(x=>x.user.id===id);if(!rec)throw new Error('Unauthorized');return rec!.user},
 async getLotBalance(token){const id=tokens.get(token);const rec=[...users.values()].find(x=>x.user.id===id);if(!rec)throw new Error('Unauthorized');return rec!.balance},
 async getListings(){return listings.filter(x=>x.active)},
 async createListing(token,payload:any){const id=tokens.get(token);if(!id)throw new Error('Unauthorized');const u=[...users.values()].find(x=>x.user.id===id)!;const item={...payload,id:randomUUID(),sellerId:id,sellerUsername:u.user.username,itemsSold:0,totalEarnedLot:0,active:true};listings.push(item);return item},
 async updateListing(token,id,payload:any){const uid=tokens.get(token);const item=listings.find(x=>x.id===id);if(!uid||!item)throw new Error('Not found');if(item.sellerId!==uid)throw new Error('You do not own this listing');Object.assign(item,payload);return item},
 async deleteListing(token,id){const uid=tokens.get(token);const i=listings.findIndex(x=>x.id===id);if(i<0)throw new Error('Not found');if(listings[i].sellerId!==uid)throw new Error('You do not own this listing');listings.splice(i,1)},
 async purchaseItem(token,id,quantity,key){const uid=tokens.get(token);const buyer=[...users.values()].find(x=>x.user.id===uid);const item=listings.find(x=>x.id===id);if(!buyer||!item)throw new Error('Item not found');if(item.stock<quantity)throw new Error('Not enough stock');const total=item.priceLot*quantity;if(buyer.balance<total)throw new Error('Insufficient LOT balance');if(key&&transactions.some(t=>t.id===key))return {transactionId:key,status:'completed',totalLot:total,remainingStock:item.stock};buyer.balance-=total;item.stock-=quantity;item.itemsSold+=quantity;item.totalEarnedLot+=total;const txn={id:key||randomUUID(),listingId:item.id,itemName:item.name,amountLot:total,buyerUsername:buyer.user.username,sellerUsername:item.sellerUsername,createdAt:new Date().toISOString(),status:'completed',direction:'purchase' as const};transactions.push(txn);return {transactionId:txn.id,status:'completed',totalLot:total,remainingStock:item.stock}},
 async getTransactions(token){const uid=tokens.get(token);const u=[...users.values()].find(x=>x.user.id===uid);if(!u)throw new Error('Unauthorized');return transactions}
}
