// LOT Shop Supabase configuration
// Publishable keys are safe to expose in browser apps.
// IMPORTANT: Set SUPABASE_URL to your Supabase project's URL.
// Example: https://your-project-ref.supabase.co
window.LOT_SUPABASE_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_0ayUczWqnjnWUxsRRI59Ag_tkY1v8_7"
};
