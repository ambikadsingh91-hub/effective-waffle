export type LotUser = { id:string; username:string; email?:string }
export type LotListing = { id:string; name:string; description:string; imageUrl:string; category:string; priceLot:number; stock:number; sellerId:string; sellerUsername:string; itemsSold:number; totalEarnedLot:number; active:boolean }
export type LotTransaction = { id:string; listingId:string; itemName:string; amountLot:number; buyerUsername:string; sellerUsername:string; createdAt:string; status:string; direction:'purchase'|'sale' }
export type LotApi = {
  loginUser(identifier:string,password:string):Promise<{accessToken:string,user:LotUser}>
  getCurrentUser(accessToken:string):Promise<LotUser>
  getLotBalance(accessToken:string):Promise<number>
  getListings(accessToken:string):Promise<LotListing[]>
  createListing(accessToken:string,payload:unknown):Promise<LotListing>
  updateListing(accessToken:string,id:string,payload:unknown):Promise<LotListing>
  deleteListing(accessToken:string,id:string):Promise<void>
  purchaseItem(accessToken:string,listingId:string,quantity:number,idempotencyKey:string):Promise<{transactionId:string,status:string,totalLot:number,remainingStock:number}>
  getTransactions(accessToken:string):Promise<LotTransaction[]>
}
