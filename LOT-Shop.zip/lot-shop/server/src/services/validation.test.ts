import { describe,it,expect } from 'vitest'
import { purchaseSchema, listingSchema } from './validation.js'
describe('validation',()=>{
 it('accepts valid listing',()=>expect(listingSchema.parse({name:'Sword',description:'Rare',imageUrl:'',category:'Weapons',priceLot:250,stock:10}).priceLot).toBe(250))
 it('rejects zero price',()=>expect(()=>listingSchema.parse({name:'x',description:'x',imageUrl:'',category:'x',priceLot:0,stock:1})).toThrow())
 it('rejects zero quantity',()=>expect(()=>purchaseSchema.parse({listingId:'x',quantity:0})).toThrow())
})
