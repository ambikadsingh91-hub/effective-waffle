import { useEffect, useMemo, useState } from 'react'
import { Link, NavLink, Route, Routes, useNavigate, useLocation } from 'react-router-dom'
import { Search, ShoppingBag, UserRound, Plus, LogOut, LayoutDashboard, History, Menu, X, Sparkles, Package, Pencil, Trash2, Power } from 'lucide-react'
import { api } from './api/client'
import type { Listing, Transaction, User } from './api/types'

const money = (n: number) => new Intl.NumberFormat('en-US').format(n)
const cats = ['All', 'Weapons', 'Collectibles', 'Accessories', 'Games', 'Other']

function Shell({ user, onLogout, children }: { user: User|null, onLogout:()=>void, children:React.ReactNode }) {
  const [open, setOpen] = useState(false)
  return <div className="app">
    <header className="nav">
      <Link to="/" className="brand" onClick={()=>setOpen(false)}><span className="brand-mark">£</span><span>LOT<span>Shop</span></span></Link>
      <div className={`nav-links ${open ? 'open' : ''}`}>
        <NavLink to="/" onClick={()=>setOpen(false)}>Marketplace</NavLink>
        {user && <><NavLink to="/dashboard" onClick={()=>setOpen(false)}>Dashboard</NavLink><NavLink to="/transactions" onClick={()=>setOpen(false)}>Transactions</NavLink></>}
      </div>
      <div className="nav-actions">
        {user ? <>
          <div className="balance"><span>Balance</span><strong>£ {money(user.lotBalance)}</strong></div>
          <Link className="sell-mini" to="/sell"><Plus size={17}/> Sell</Link>
          <Link className="profile-chip" to="/account"><UserRound size={18}/><span>{user.username}</span></Link>
          <button className="icon-btn mobile-menu" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
        </> : <Link className="btn primary" to="/login">Log in</Link>}
      </div>
    </header>
    <main>{children}</main>
    <footer><div><b>£ LOT Shop</b><p>A premium marketplace powered by your LOT API.</p></div><span>Secure • Responsive • API-first</span></footer>
  </div>
}

function Home({ user, refreshUser }: {user:User|null, refreshUser:()=>Promise<void>}) {
  const [listings,setListings]=useState<Listing[]>([])
  const [query,setQuery]=useState('')
  const [cat,setCat]=useState('All')
  const [loading,setLoading]=useState(true)
  const [selected,setSelected]=useState<Listing|null>(null)
  const [notice,setNotice]=useState('')
  const load=async()=>{setLoading(true); try{setListings((await api.getListings()).listings)}catch(e){setNotice((e as Error).message)}finally{setLoading(false)}}
  useEffect(()=>{load()},[])
  const filtered=useMemo(()=>listings.filter(x=>(cat==='All'||x.category===cat)&&`${x.name} ${x.description} ${x.sellerUsername}`.toLowerCase().includes(query.toLowerCase())),[listings,query,cat])
  const buy=async()=>{if(!selected||!user)return; try{const r=await api.purchaseItem(selected.id); setNotice(`Purchase complete • ${r.totalLot.toLocaleString()} LOT`); setSelected(null); await Promise.all([load(),refreshUser()])}catch(e){setNotice((e as Error).message)}}
  return <div className="container">
    <section className="hero">
      <div><div className="eyebrow"><Sparkles size={15}/> THE LOT MARKETPLACE</div><h1>Buy rare.<br/><em>Sell smart.</em></h1><p>Discover player-listed items and trade with confidence using your real LOT balance.</p><div className="hero-actions"><a href="#market" className="btn primary">Explore marketplace</a>{user&&<Link to="/sell" className="btn ghost">List an item <Plus size={16}/></Link>}</div></div>
      <div className="hero-card"><div className="hero-orb">£</div><span>LIVE MARKET</span><strong>{listings.length} listings</strong><small>Prices and stock are verified server-side.</small></div>
    </section>
    <section id="market" className="market">
      <div className="section-head"><div><p className="kicker">MARKETPLACE</p><h2>Find your next item</h2></div><div className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search items, sellers..."/></div></div>
      <div className="chips">{cats.map(c=><button key={c} className={cat===c?'active':''} onClick={()=>setCat(c)}>{c}</button>)}</div>
      {notice&&<div className="notice">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
      {loading?<div className="grid">{Array.from({length:6}).map((_,i)=><div className="card skeleton" key={i}/>)}</div>:filtered.length?<div className="grid">{filtered.map(x=><article className="item-card" key={x.id}>
        <div className="item-image">{x.imageUrl?<img src={x.imageUrl} alt=""/>:<Package size={42}/>}<span>{x.category}</span></div>
        <div className="item-body"><h3>{x.name}</h3><p>{x.description}</p><div className="seller">Seller <b>{x.sellerUsername}</b></div><div className="item-foot"><div><small>PRICE</small><strong>£ {money(x.priceLot)}</strong></div><div><small>STOCK</small><strong>{x.stock}</strong></div><button disabled={!user||x.stock<1} className="btn primary small" onClick={()=>setSelected(x)}>{x.stock<1?'Sold out':user?'Buy now':'Log in to buy'}</button></div></div>
      </article>)}</div>:<div className="empty"><ShoppingBag size={36}/><h3>No items found</h3><p>Try another search or category.</p></div>}
    </section>
    {selected&&<div className="overlay"><div className="modal"><button className="modal-x" onClick={()=>setSelected(null)}>×</button><p className="kicker">CONFIRM PURCHASE</p><h2>Purchase {selected.name}?</h2><div className="confirm-grid"><span>Price</span><b>£ {money(selected.priceLot)}</b><span>Your balance</span><b>£ {money(user?.lotBalance||0)}</b><span>Remaining</span><b>£ {money((user?.lotBalance||0)-selected.priceLot)}</b></div>{(user?.lotBalance||0)<selected.priceLot&&<div className="error-box">Insufficient LOT balance.</div>}<div className="modal-actions"><button className="btn ghost" onClick={()=>setSelected(null)}>Cancel</button><button className="btn primary" disabled={(user?.lotBalance||0)<selected.priceLot} onClick={buy}>Confirm purchase</button></div></div></div>}
  </div>
}

function Login({onLogin}:{onLogin:(u:User)=>void}) {
  const [identifier,setIdentifier]=useState(''); const [password,setPassword]=useState(''); const [busy,setBusy]=useState(false); const [error,setError]=useState('')
  const submit=async(e:React.FormEvent)=>{e.preventDefault();setBusy(true);setError('');try{const r=await api.loginUser(identifier,password);onLogin(r.user)}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  return <div className="auth"><div className="auth-panel"><Link to="/" className="brand"><span className="brand-mark">£</span><span>LOTS<span>hop</span></span></Link><p className="kicker">WELCOME BACK</p><h1>Sign in to LOT Shop</h1><p className="muted">Use the same credentials as your LOT account.</p><form onSubmit={submit}>{error&&<div className="error-box">{error}</div>}<label>Username or email<input required value={identifier} onChange={e=>setIdentifier(e.target.value)} autoComplete="username"/></label><label>Password<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></label><button className="btn primary full" disabled={busy}>{busy?'Signing in...':'Sign in'}</button></form><Link className="back" to="/">← Back to marketplace</Link></div></div>
}

function Sell({user}:{user:User}) {
  const nav=useNavigate(); const [form,setForm]=useState({name:'',description:'',priceLot:'',stock:'1',category:'Other',imageUrl:''}); const [busy,setBusy]=useState(false); const [error,setError]=useState('')
  const upload=async(e:React.ChangeEvent<HTMLInputElement>)=>{const f=e.target.files?.[0];if(!f)return;try{setBusy(true);setForm(x=>({...x,imageUrl:''}));const url=await api.uploadImage(f);setForm(x=>({...x,imageUrl:url}))}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  const submit=async(e:React.FormEvent)=>{e.preventDefault();setBusy(true);setError('');try{await api.createListing({...form,priceLot:Number(form.priceLot),stock:Number(form.stock)} as any);nav('/dashboard')}catch(e){setError((e as Error).message)}finally{setBusy(false)}}
  return <div className="container narrow"><div className="page-head"><p className="kicker">SELL</p><h1>Create a listing</h1><p>Publish an item to the LOT marketplace.</p></div><form className="form-card" onSubmit={submit}>{error&&<div className="error-box">{error}</div>}<div className="upload"><input type="file" accept="image/jpeg,image/png,image/webp" onChange={upload}/>{form.imageUrl?<img src={form.imageUrl} alt="Preview"/>:<div><Plus/><b>Upload item image</b><small>JPG, PNG or WebP • max 5 MB</small></div>}</div><label>Item name<input required maxLength={100} value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Description<textarea required maxLength={1000} value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label><div className="two"><label>Price (LOT)<input required type="number" min="1" step="1" value={form.priceLot} onChange={e=>setForm({...form,priceLot:e.target.value})}/></label><label>Stock<input required type="number" min="1" step="1" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})}/></label></div><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{cats.slice(1).map(c=><option key={c}>{c}</option>)}</select></label><div className="form-actions"><button type="button" className="btn ghost" onClick={()=>nav(-1)}>Cancel</button><button className="btn primary" disabled={busy}>{busy?'Publishing...':'Publish item'}</button></div></form></div>
}

function Dashboard(){const [items,setItems]=useState<Listing[]>([]);const [busy,setBusy]=useState(true);const [notice,setNotice]=useState('');const load=async()=>{setBusy(true);try{setItems((await api.getListings()).listings.filter(x=>x.sellerId))}finally{setBusy(false)}};useEffect(()=>{load()},[]);return <div className="container"><div className="page-head split"><div><p className="kicker">SELLER CENTER</p><h1>My listings</h1><p>Manage your inventory and offers.</p></div><Link to="/sell" className="btn primary"><Plus size={17}/> New listing</Link></div>{notice&&<div className="notice">{notice}</div>}{busy?<div className="card skeleton tall"/>:<div className="table-wrap"><table><thead><tr><th>Item</th><th>Price</th><th>Stock</th><th>Sold</th><th>Earned</th><th></th></tr></thead><tbody>{items.map(x=><tr key={x.id}><td><div className="table-item">{x.imageUrl&&<img src={x.imageUrl}/>}<b>{x.name}</b></div></td><td>£ {money(x.priceLot)}</td><td>{x.stock}</td><td>{x.itemsSold}</td><td>£ {money(x.totalEarnedLot)}</td><td><div className="row-actions"><button title="Toggle active" onClick={async()=>{await api.updateListing(x.id,{active:!x.active});load()}}><Power/></button><button title="Delete" onClick={async()=>{if(confirm('Delete this listing?')){await api.deleteListing(x.id);load()}}}><Trash2/></button></div></td></tr>)}</tbody></table>{!items.length&&<div className="empty"><h3>No listings yet</h3><Link to="/sell" className="btn primary">Create your first listing</Link></div>}</div>}</div>}

function Transactions(){const [data,setData]=useState<Transaction[]>([]);useEffect(()=>{api.getTransactions().then(r=>setData(r.transactions))},[]);return <div className="container"><div className="page-head"><p className="kicker">ACTIVITY</p><h1>Transactions</h1><p>Your purchases and sales.</p></div><div className="transaction-list">{data.map(t=><div className="transaction" key={t.id}><div className="txn-icon">{t.direction==='purchase'?'↓':'↑'}</div><div><b>{t.itemName}</b><span>{t.direction==='purchase'?'Bought from':'Sold to'} {t.direction==='purchase'?t.sellerUsername:t.buyerUsername}</span></div><strong className={t.direction==='purchase'?'out':'in'}>{t.direction==='purchase'?'-':'+'} £ {money(t.amountLot)}</strong><small>{new Date(t.createdAt).toLocaleString()}</small><span className="status">{t.status}</span></div>)}</div></div>}

function Account({user,onLogout}:{user:User,onLogout:()=>void}){return <div className="container"><div className="account-card"><div className="avatar">{user.username.slice(0,1).toUpperCase()}</div><p className="kicker">ACCOUNT</p><h1>{user.username}</h1><p className="muted">LOT balance</p><div className="big-balance">£ {money(user.lotBalance)}</div><div className="stats"><div><b>—</b><span>Listings</span></div><div><b>—</b><span>Purchases</span></div><div><b>—</b><span>Sales</span></div></div><button className="btn danger" onClick={onLogout}><LogOut size={17}/> Log out</button></div></div>}

export default function App(){
  const [user,setUser]=useState<User|null>(null); const [ready,setReady]=useState(false); const loc=useLocation(); const nav=useNavigate()
  const refreshUser=async()=>{try{const [u,b]=await Promise.all([api.getCurrentUser(),api.getLotBalance()]);setUser({...u.user,lotBalance:b.lotBalance})}catch{setUser(null)}}
  useEffect(()=>{refreshUser().finally(()=>setReady(true))},[])
  const login=(u:User)=>{setUser(u);nav('/')}
  const logout=async()=>{await api.logout().catch(()=>{});setUser(null);nav('/')}
  if(!ready)return <div className="loading-screen"><span className="brand-mark">£</span><b>LOT Shop</b></div>
  if(!user && !['/','/login'].includes(loc.pathname)) return <><Shell user={null} onLogout={logout}><Login onLogin={login}/></Shell></>
  return <Shell user={user} onLogout={logout}><Routes><Route path="/" element={<Home user={user} refreshUser={refreshUser}/>}/><Route path="/login" element={<Login onLogin={login}/>}/>{user&&<><Route path="/sell" element={<Sell user={user}/>}/><Route path="/dashboard" element={<Dashboard/>}/><Route path="/transactions" element={<Transactions/>}/><Route path="/account" element={<Account user={user} onLogout={logout}/>}/></>}</Routes></Shell>
}
