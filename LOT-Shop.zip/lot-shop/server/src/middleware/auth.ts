import type { Request,Response,NextFunction } from 'express'
import { lotApi } from '../adapters/lotApi.js'

declare global { namespace Express { interface Request { lotToken?: string } } }

export async function requireAuth(req:Request,res:Response,next:NextFunction){
  const token=req.cookies?.lot_session
  if(!token)return res.status(401).json({message:'Authentication required'})
  try{await lotApi.getCurrentUser(token);req.lotToken=token;next()}catch{return res.status(401).json({message:'Session expired. Please log in again.'})}
}
