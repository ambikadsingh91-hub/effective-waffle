import type { Listing, Transaction, User } from './types'

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`/api${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
    ...init
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.message || 'Request failed')
  return data
}

export const api = {
  loginUser: (identifier: string, password: string) =>
    request<{ user: User }>('/auth/login', { method: 'POST', body: JSON.stringify({ identifier, password }) }),
  logout: () => request<{ ok: true }>('/auth/logout', { method: 'POST' }),
  getCurrentUser: () => request<{ user: User }>('/users/me'),
  getLotBalance: () => request<{ lotBalance: number }>('/users/me/balance'),
  getListings: () => request<{ listings: Listing[] }>('/marketplace/listings'),
  createListing: (payload: Omit<Listing, 'id'|'sellerId'|'sellerUsername'|'itemsSold'|'totalEarnedLot'|'active'|'imageUrl'> & { imageUrl: string }) =>
    request<{ listing: Listing }>('/marketplace/listings', { method: 'POST', body: JSON.stringify(payload) }),
  updateListing: (id: string, payload: Partial<Listing>) =>
    request<{ listing: Listing }>(`/marketplace/listings/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
  deleteListing: (id: string) =>
    request<{ ok: true }>(`/marketplace/listings/${id}`, { method: 'DELETE' }),
  purchaseItem: (listingId: string, quantity = 1) =>
    request<{ transactionId: string; status: string; totalLot: number; remainingStock: number }>(
      '/marketplace/purchases',
      { method: 'POST', headers: { 'Idempotency-Key': crypto.randomUUID() }, body: JSON.stringify({ listingId, quantity }) }
    ),
  getTransactions: () => request<{ transactions: Transaction[] }>('/transactions'),
  uploadImage: async (file: File) => {
    const form = new FormData()
    form.append('image', file)
    const res = await fetch('/api/uploads/image', { method: 'POST', credentials: 'include', body: form })
    const data = await res.json()
    if (!res.ok) throw new Error(data.message || 'Upload failed')
    return data.imageUrl as string
  }
}
