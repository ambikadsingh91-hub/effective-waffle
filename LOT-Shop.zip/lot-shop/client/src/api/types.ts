export type User = {
  id: string
  username: string
  email?: string
  lotBalance: number
}

export type Listing = {
  id: string
  name: string
  description: string
  imageUrl: string
  category: string
  priceLot: number
  stock: number
  sellerId: string
  sellerUsername: string
  itemsSold: number
  totalEarnedLot: number
  active: boolean
}

export type Transaction = {
  id: string
  listingId: string
  itemName: string
  amountLot: number
  buyerUsername: string
  sellerUsername: string
  createdAt: string
  status: string
  direction: 'purchase' | 'sale'
}
