import 'dotenv/config'
import express from 'express'
import cookieParser from 'cookie-parser'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import multer from 'multer'
import path from 'node:path'
import fs from 'node:fs'
import { randomUUID } from 'node:crypto'
import { lotApi } from './adapters/lotApi.js'
import { requireAuth } from './middleware/auth.js'
import { loginSchema, listingSchema, updateListingSchema, purchaseSchema } from './services/validation.js'

const app=express()
const port=Number(process.env.PORT||4000)
const origin=process.env.CLIENT_ORIGIN||'http://localhost:5173'
app.use(helmet())
app.use(cors({origin,credentials:true}))
app.use(express.json({limit:'100kb'}))
app.use(cookieParser())
const authLimiter=rateLimit({windowMs:15*60*1000,max:30,standardHeaders:true,legacyHeaders:false})
const purchaseLimiter=rateLimit({windowMs:60*1000,max:30,standardHeaders:true,legacyHeaders:false})
const cookieOpts={httpOnly:true,sameSite:'lax' as const,secure:process.env.COOKIE_SECURE==='true',maxAge:7*24*60*60*1000}

app.post('/api/auth/login',authLimiter,async(req,res)=>{try{const {identifier,password}=loginSchema.parse(req.body);const r=await lotApi.loginUser(identifier,password);res.cookie('lot_session',r.accessToken,cookieOpts);const balance=await lotApi.getLotBalance(r.accessToken);res.json({user:{...r.user,lotBalance:balance}})}catch(e){res.status(401).json({message:(e as Error).message||'Unable to sign in'})}})
app.post('/api/auth/logout',(req,res)=>{res.clearCookie('lot_session');res.json({ok:true})})

app.get('/api/users/me',requireAuth,async(req,res)=>{try{const user=await lotApi.getCurrentUser(req.lotToken!);const lotBalance=await lotApi.getLotBalance(req.lotToken!);res.json({user:{...user,lotBalance}})}catch(e){res.status(401).json({message:(e as Error).message})}})
app.get('/api/users/me/balance',requireAuth,async(req,res)=>{try{res.json({lotBalance:await lotApi.getLotBalance(req.lotToken!)})}catch(e){res.status(502).json({message:(e as Error).message})}})

app.get('/api/marketplace/listings',async(req,res)=>{try{res.json({listings:await lotApi.getListings(req.cookies?.lot_session||'')})}catch(e){res.status(502).json({message:(e as Error).message})}})
app.post('/api/marketplace/listings',requireAuth,async(req,res)=>{try{const payload=listingSchema.parse(req.body);res.status(201).json({listing:await lotApi.createListing(req.lotToken!,payload)})}catch(e){res.status(400).json({message:(e as Error).message})}})
app.patch('/api/marketplace/listings/:id',requireAuth,async(req,res)=>{try{const payload=updateListingSchema.parse(req.body);res.json({listing:await lotApi.updateListing(req.lotToken!,req.params.id,payload)})}catch(e){res.status(403).json({message:(e as Error).message})}})
app.delete('/api/marketplace/listings/:id',requireAuth,async(req,res)=>{try{await lotApi.deleteListing(req.lotToken!,req.params.id);res.json({ok:true})}catch(e){res.status(403).json({message:(e as Error).message})}})

app.post('/api/marketplace/purchases',requireAuth,purchaseLimiter,async(req,res)=>{
  const key=req.get('Idempotency-Key')||randomUUID()
  try{
    const {listingId,quantity}=purchaseSchema.parse(req.body)
    // IMPORTANT: price, balance, seller and stock are NOT accepted from the browser.
    // The authoritative LOT API must perform the atomic transaction.
    const result=await lotApi.purchaseItem(req.lotToken!,listingId,quantity,key)
    res.status(201).json(result)
  }catch(e){res.status(400).json({message:(e as Error).message||'Purchase failed'})}
})

app.get('/api/transactions',requireAuth,async(req,res)=>{try{res.json({transactions:await lotApi.getTransactions(req.lotToken!)})}catch(e){res.status(502).json({message:(e as Error).message})}})

const uploadDir=path.resolve(process.env.UPLOAD_DIR||'./uploads')
fs.mkdirSync(uploadDir,{recursive:true})
const upload=multer({storage:multer.diskStorage({destination:uploadDir,filename:(_,file,cb)=>cb(null,`${randomUUID()}${path.extname(file.originalname).toLowerCase()}`)}),limits:{fileSize:5*1024*1024},fileFilter:(_,file,cb)=>cb(null,['image/jpeg','image/png','image/webp'].includes(file.mimetype))})
app.post('/api/uploads/image',requireAuth,upload.single('image'),(req,res)=>{if(!req.file)return res.status(400).json({message:'Valid JPG, PNG or WebP image required'});res.json({imageUrl:`/uploads/${req.file.filename}`})})
app.use('/uploads',express.static(uploadDir,{maxAge:'7d',index:false}))

app.get('/api/health',(_,res)=>res.json({ok:true,mode:process.env.LOT_API_MODE||'mock'}))
app.use((err:any,_req:any,res:any,_next:any)=>res.status(500).json({message:'Unexpected server error'}))
app.listen(port,()=>console.log(`LOT Shop server running on http://localhost:${port}`))
