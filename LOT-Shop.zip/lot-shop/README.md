# LOT Shop

A production-oriented marketplace starter for LOT Shop. The UI is complete and responsive; all account, LOT-balance, checkout, listing, upload, and transaction operations are isolated behind a server-side API adapter so your real LOT API can be connected without rewriting the UI.

## Stack

- React + Vite + TypeScript
- Express + TypeScript backend
- Zod validation
- JWT-backed server session cookie
- SQLite-ready Prisma schema for marketplace metadata
- CSS-only responsive design and animations
- Vitest unit tests for core validation/business helpers

## Important API note

The value you previously supplied (`sb_publishable_...`) is a Supabase **publishable** key. It is not a secret API key and by itself does not provide the LOT account/balance/purchase API described in the specification. This project therefore does **not** pretend that key can authenticate users or move LOT.

Do not put a secret LOT API key in the browser. Configure it only in the server environment.

## Project structure

```text
lot-shop/
  client/
    src/
      api/
        client.ts
        types.ts
      components/
      pages/
      App.tsx
      main.tsx
      styles.css
  server/
    src/
      adapters/
        lotApi.ts
        mockLotApi.ts
      middleware/
      routes/
      services/
      db/
      index.ts
    prisma/schema.prisma
  .env.example
  package.json
  README.md
  .gitignore
```

## Setup

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

This starts:
- frontend: http://localhost:5173
- backend: http://localhost:4000

For development without a real LOT API, set:

```env
LOT_API_MODE=mock
```

Mock mode is deliberately isolated in `server/src/adapters/mockLotApi.ts` and must not be used as the production source of truth.

## Connect your real LOT API

Copy `.env.example` to `.env`.

Set:

```env
LOT_API_MODE=real
LOT_API_BASE_URL=https://your-real-api.example
LOT_API_AUTH_HEADER=Authorization
LOT_API_AUTH_SCHEME=Bearer
LOT_API_SECRET=your_server_only_secret
```

Then edit **only** `server/src/adapters/lotApi.ts` if your API's routes or request/response shapes differ.

The adapter exposes:

- `loginUser()`
- `getCurrentUser()`
- `getLotBalance()`
- `getListings()`
- `createListing()`
- `updateListing()`
- `deleteListing()`
- `purchaseItem()`
- `getTransactions()`

### Expected real API contract

The server expects these logical operations. Your actual paths may differ.

`POST /auth/login`
```json
{ "identifier": "username-or-email", "password": "..." }
```

Expected:
```json
{
  "accessToken": "server-side-token",
  "user": { "id": "user-id", "username": "ExampleUser", "email": "x@example.com" }
}
```

`GET /users/me`
Expected:
```json
{ "id": "user-id", "username": "ExampleUser", "email": "x@example.com" }
```

`GET /users/me/balance`
Expected:
```json
{ "lot": 5000 }
```

Marketplace logical operations:
- `GET /marketplace/listings`
- `POST /marketplace/listings`
- `PATCH /marketplace/listings/:id`
- `DELETE /marketplace/listings/:id`
- `POST /marketplace/purchases`
- `GET /transactions`

Purchase request should be authoritative server-side:
```json
{ "listingId": "listing-id", "quantity": 1 }
```

Purchase response should confirm the authoritative transaction:
```json
{
  "transactionId": "txn-id",
  "status": "completed",
  "totalLot": 250,
  "remainingStock": 11
}
```

**Do not implement checkout by trusting a frontend price or balance.** The server sends the listing ID and quantity to the LOT API; the LOT API/database must resolve the current price, stock, buyer balance, seller, and payout atomically.

If your LOT API cannot atomically reserve stock + debit buyer + credit seller + create transaction, add that operation to the API first (recommended: one `POST /marketplace/purchases` transaction endpoint).

## Database

Prisma is included for marketplace metadata/reference records. The user's LOT balance is intentionally NOT stored as a permanent local balance.

Schema concepts:
- `ApiUserRef`
- `Listing`
- `Transaction`

For production, use PostgreSQL or your managed database. SQLite is convenient for local development.

```bash
npm run db:generate
npm run db:push
```

## Uploads

The backend has an upload endpoint with:
- authenticated session requirement
- MIME/type allowlist
- 5 MB limit
- generated filename
- no trust in the browser filename

Set `UPLOAD_DIR` to durable object storage in production. If your LOT API provides secure media upload/storage, replace the upload implementation in `server/src/routes/uploads.ts`.

## Security checklist

- Passwords are sent only to the server-side login route and are never persisted.
- No secret API credentials are bundled into Vite.
- Server validates listing fields with Zod.
- Listing edits/deletes require ownership.
- Purchase uses the listing ID, not client-supplied authoritative price.
- Purchase route has an in-process idempotency guard; production should also enforce an idempotency key/unique transaction constraint in the authoritative API.
- Login and purchase endpoints include basic rate limiting.
- Security headers are enabled with Helmet.
- Cookies are HTTP-only.
- Production should run behind HTTPS and set `COOKIE_SECURE=true`.
- Use a real distributed rate limiter (Redis or gateway) when scaling beyond one backend instance.

## Production

```bash
npm run build
npm run start
```

Builds both client and server. Configure the production environment variables first.

## Testing

```bash
npm test
```

The included tests cover validation and purchase idempotency helper behavior. Real API integration tests should be added after the real API contract is supplied.

## Supabase

If you intend to use Supabase for the marketplace database/storage, add its project URL and publishable key to the environment and connect it in the server/database layer. The `sb_publishable_...` key you supplied should be treated as a client/publishable credential, not as a replacement for the LOT API's authentication and balance endpoints.
