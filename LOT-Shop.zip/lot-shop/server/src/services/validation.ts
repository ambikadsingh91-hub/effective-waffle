import { z } from 'zod'
export const loginSchema=z.object({identifier:z.string().trim().min(1).max(150),password:z.string().min(1).max(200)})
export const listingSchema=z.object({name:z.string().trim().min(1).max(100),description:z.string().trim().min(1).max(1000),imageUrl:z.string().max(2000),category:z.string().trim().min(1).max(50),priceLot:z.number().int().positive().max(1_000_000_000),stock:z.number().int().positive().max(1_000_000)})
export const updateListingSchema=listingSchema.partial().extend({active:z.boolean().optional()})
export const purchaseSchema=z.object({listingId:z.string().min(1).max(200),quantity:z.number().int().positive().max(100)})
