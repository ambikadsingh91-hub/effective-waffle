import type { LotApi } from '../types.js'
import { mockLotApi } from './mockLotApi.js'

/**
 * REAL LOT API ADAPTER
 *
 * Replace the endpoint paths and response mappings below with the API
 * documentation you provide later. Keep this interface unchanged so the UI
 * and routes do not need to change.
 */
const base = process.env.LOT_API_BASE_URL || ''
const secret = process.env.LOT_API_SECRET || ''
const header = process.env.LOT_API_AUTH_HEADER || 'Authorization'
const scheme = process.env.LOT_API_AUTH_SCHEME || 'Bearer'

async function http(path:string, init:RequestInit={}, token?:string){
  const headers = new Headers(init.headers)
  headers.set('Content-Type','application/json')
  if(secret && !token) headers.set('X-Server-Api-Key',secret)
  if(token) headers.set(header, `${scheme} ${token}`)
  const res=await fetch(`${base}${path}`,{...init,headers})
  const data=await res.json().catch(()=>({}))
  if(!res.ok) throw new Error(data.message||data.error||`LOT API error (${res.status})`)
  return data
}

export const realLotApi: LotApi = {
 async loginUser(identifier,password){const d=await http('/auth/login',{method:'POST',body:JSON.stringify({identifier,password})});return {accessToken:d.accessToken,user:d.user}},
 async getCurrentUser(token){return (await http('/users/me',{},token)).user??await http('/users/me',{},token)},
 async getLotBalance(token){const d=await http('/users/me/balance',{},token);return Number(d.lot??d.lotBalance)},
 async getListings(token){return (await http('/marketplace/listings',{},token)).listings},
 async createListing(token,payload){return (await http('/marketplace/listings',{method:'POST',body:JSON.stringify(payload)},token)).listing},
 async updateListing(token,id,payload){return (await http(`/marketplace/listings/${id}`,{method:'PATCH',body:JSON.stringify(payload)},token)).listing},
 async deleteListing(token,id){await http(`/marketplace/listings/${id}`,{method:'DELETE'},token)},
 async purchaseItem(token,listingId,quantity,idempotencyKey){return await http('/marketplace/purchases',{method:'POST',headers:{'Idempotency-Key':idempotencyKey},body:JSON.stringify({listingId,quantity})},token)},
 async getTransactions(token){return (await http('/transactions',{},token)).transactions}
}

export const lotApi: LotApi = process.env.LOT_API_MODE === 'real' ? realLotApi : mockLotApi
