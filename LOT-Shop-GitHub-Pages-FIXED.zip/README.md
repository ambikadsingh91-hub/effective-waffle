# LOT Shop — GitHub Pages Ready

This ZIP is prepared specifically for a GitHub Pages repository.

## Fix for the 404
Upload the CONTENTS of this ZIP to the ROOT of your `effective-waffle` repository.
`index.html` must be directly in the repository root.

Then:
1. GitHub → Settings → Pages
2. Source: Deploy from a branch
3. Branch: `main`
4. Folder: `/ (root)`
5. Save and wait for deployment.

## Supabase
`supabase-config.js` contains the Supabase publishable key you supplied.
You still need to set `SUPABASE_URL` to your Supabase project URL.

A publishable key does not contain the project URL, so it cannot be safely inferred from the key alone.

## Important
The site stays in DEMO mode until the real LOT API/service layer is connected.
Do not treat the demo balance or demo transactions as real LOT balances.

For production, connect authentication, balance verification, listing operations,
uploads, purchases, stock changes, payouts, and transaction recording to the real
server-side/API layer. Never put a secret/service-role key in this repository.
